var sandeshTop= [];
var sandeshInterval; 
var flag;  //here three different variables are intialized. 

function sandeshStart(){
	var satart= document.getElementById('start');
	

	document.getElementById('start').disabled= 'true';
	satart.addEventListener('click', sandeshDown);  //eventlistener is used here.


	




}


// function sandeshBet(){
// amount= document.getElementById('amount').value;
// bet_amt= document.getElementById('bethorse').value;

//   if(amount >funds ){
// 		alert('sorry');
// 	}
// 	else if(amount>0){
// 		alert('no fund');
// 		sandeshInterval=setInterval(runDown,10);
		
// 	}
	
// 	else  {
// 		alert('Hello world');
		
	

// }

// }



	function sandeshDown(){   //function name sandeshdown is given here.
	var sandHorse = document.getElementsByClassName('horse');
	sandHorse[0].className= 'horse runDown';
	sandHorse[1].className= 'horse runDown';
	sandHorse[2].className= 'horse runDown';
	sandHorse[3].className= 'horse runDown';




	 sandeshTop[0]= sandHorse[0].offsetTop;
	 sandeshTop[1]= sandHorse[1].offsetTop;
	 sandeshTop[2]= sandHorse[2].offsetTop;
	 sandeshTop[3]= sandHorse[3].offsetTop;


	sandHorse[0].style.top= sandeshTop[0] + Math.ceil(Math.random()*4) + 'px';
	sandHorse[1].style.top= sandeshTop[1] + Math.ceil(Math.random()*4) + 'px';
	sandHorse[2].style.top= sandeshTop[2] + Math.ceil(Math.random()*4) + 'px';
	sandHorse[3].style.top= sandeshTop[3] + Math.ceil(Math.random()*4) + 'px';

	if(sandeshTop[0]>=10){

		clearInterval(sandeshInterval);
		sandeshInterval= setInterval(sandeshStop, 10	);
	}	

	if(sandeshTop[1]>=10){

		clearInterval(sandeshInterval);
		sandeshInterval= setInterval(sandeshDown, 10);
	}

	if(sandeshTop[2]==10){

		clearInterval(sandeshInterval);
		sandeshInterval= setInterval(sandeshDown, 10);
	}

	if(sandeshTop[3]==10){

		clearInterval(sandeshInterval);
		sandeshInterval= setInterval(sandeshDown, 10);
	}
	
		
	
sandeshJump();
sandeshStop();
	
	scrollTrack();	


}
function sandeshReset(){

		// document.getElementById("reset").reset();
location.reload();

}


function sandeshStop(){
var sandHorse= document.getElementsByClassName('horse');

	

for(var i=0;i<4;i++){
	if(sandeshTop[i]<=2600 ){
			
		
			sandHorse[i].className= 'horse runDown';
           
            sandeshTop[i]= sandHorse[i].offsetTop;
			// clearInterval(sandeshInterval);
		
	}
	else{
					 sandHorse[i].className= 'horse standDown';
					 
					clearInterval(sandeshInterval);

	}
				

}
	
}
function sandeshJump(){
	var element= document.getElementsByClassName('horse');
	for (var i=0 ; i<4; i++){
		if(sandeshTop>=50 || sandeshTop<=80 || sandeshTop<=120 || sandeshTop<=180 || sandeshTop<=200 || sandeshTop<=250){
		element[i].className= 'horse jump';

		console.log('jump');
	}
	else{
		element[i].className='horse runDown';
	}
}
}



function scrollTrack() {

	setInterval(function() {
		var scroller = document.getElementById('scroll');
		scroller.scrollTop = scroller.scrollTop + 0.999;
	}, 1400);
	// sandeshStart();	
	 
}

function sandeshh(){

	var satart= document.getElementById('start');
	satart.addEventListener('click', sandeshDown);
	
sandeshBet();

}



document.addEventListener('DOMContentLoaded', sandeshh);

